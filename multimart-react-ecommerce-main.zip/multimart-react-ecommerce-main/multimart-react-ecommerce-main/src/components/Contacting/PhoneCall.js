import React from 'react'

export default function PhoneCall() {
  return (
    <div>
     


    
      
      <a href="tel:+918847414135">
      <div className='imagecontacting'>
      <img src="https://w7.pngwing.com/pngs/731/937/png-transparent-mobile-phones-telephone-handset-phone-icon-miscellaneous-angle-telephone-call-thumbnail.png" alt="Phone Call" />
      </div>
        
      </a>
    </div>
  );
}



    
 
