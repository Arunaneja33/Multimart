import React from 'react'
import "./contacting.css"
export default function Email() {
  return (
    <div>
      <p>
       
        <a href="mailto:">
        <div className='imagecontacting'>
        <img  src="https://tse1.mm.bing.net/th?id=OIP.IpB5yPUkCFHOzlmM-O7ncAHaFW&pid=Api&P=0&h=180" alt="Email" />
        </div>
         
          
        </a>
        </p>
    </div>
  )
}
