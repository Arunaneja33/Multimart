import React from 'react'

export default function ComplaintRegisterSuccessfully() {
  return (
    <div>
    <h2>
        Your Complaint Register Complaint Register Successfully
    </h2>
      
    </div>
  )
}
